<!DOCTYPE html>
<html>
<title>On-Line Vote</title>
    <head>
	<link rel="icon" type='image/png' href="vote.png" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo $title; ?></title>
        <link rel="stylesheet" type="text/css" href="Styles/Stylesheet.css" />
		<script type="text/javascript">
		<!-->
var image1=new Image()
image1.src="vote1.jpg"
var image2=new Image()
image2.src="vote2.jpg"
var image3=new Image()
image3.src="Election.jpg"
//-->

</script>
    </head>
    <body>
        <div id="wrapper">
            <div id="banner">             
            </div>
            
            <div id="nav">
                <div id="nav_wrapper">
				<ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Login<img src="arr6.png" /></a>
					<ul>
					<li><a href="#">Voter</a></a></li>
					<li><a href="#">Counting Officer</a></li>
					<li><a href="#">Presiding Officer</a></li>
					</ul>	
					</li>	
                    <li><a href="#">Instructions</a></li>
		            <li><a href="#">About</a></li>
                </ul>
				</div>
            </div>
            
            <div id="content_area" style="color:#ffffff">
               <h1>The Zonewise Result for</h1>
				<?php
include_once("dbc.php");
session_start();
?>

<?php
$n=mysql_query("select zone.zname from candidate,party,worker,zone where worker.wid='". $_SESSION['poid']. "' and worker.zid = candidate.zid and zone.zid = candidate.zid and candidate.pid = party.pid order by cname Asc ")or die(mysql_error());
$a=mysql_fetch_array($n);
echo "<h3>".$a['zname']."</h3>";
$namep=mysql_query("select candidate.zid, candidate.cname, party.pname, candidate.votes from candidate,party,worker where worker.wid='". $_SESSION['poid']. "' and worker.zid = candidate.zid and candidate.pid = party.pid order by cname Asc ")or die(mysql_error());
echo "<br /><br /><table border='1' bgcolor=#CC9933>";
echo "<tr><th>Candidate Name</th><th>Party</th><th>Total Votes</th></tr>";

while($row = mysql_fetch_array($namep)){  
echo "<form action=co_counted.php method=post>";
//$img=$row['pic'];
//header("Content-type:Image/jpeg");
echo "<tr></td><td>" . $row['cname'] . "</td><td>" . $row['pname'] . "</td><td>" . $row['votes'] . "</td></tr>";  //$row['index'] the index here is a field name

echo "</form>";
//$_SESSION['party']=$row['pname'];
}
echo "</table>";
/*$maxvote=0;$minvote=0;
$smax=mysql_query("select candidate.vote from candidate");
while($smaxx=mysql_fetch_array($smax)){
$array=$maxx['candidate.vote'];
$minvote=
if($array>$maxvote)
{
$maxvote=$array;
}

}
*/
$q=mysql_query("select max(candidate.votes) as maxim from candidate,party,worker where worker.wid='". $_SESSION['poid']. "' and worker.zid = candidate.zid and candidate.pid = party.pid ")or die(mysql_error());
$res=mysql_fetch_array($q);
$qi=mysql_query("select min(candidate.votes) as minim from candidate,party,worker where worker.wid='". $_SESSION['poid']. "' and worker.zid = candidate.zid and candidate.pid = party.pid ")or die(mysql_error());
$resi=mysql_fetch_array($qi);
$qq=mysql_query("select party.pname, candidate.cname from party join candidate on party.pid=candidate.pid where candidate.votes='".$res['maxim']."'");
$name=mysql_fetch_array($qq);
$sub=($res['maxim']-$resi['minim']);
if($sub==0)
echo "<br /><br /><h2>It is a tie!</h2>";
else
echo "<br /><h2>Candidate ". $name['cname'] ." who stood by ".$name['pname']." won with a margin of ". $sub . " votes.</h2>";
?><div style="text-align:center;">
<br /><br /><a href='co_logout.php'><img src='Images/logout-button.png' height='100'></a>
</div>


				
				
				
            </div>
            
            <div id="sidebar">
             <img src="vote1.jpg" name="slide" width="100%" height="100%">
<script type="text/javascript">
<!--
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<3)
step++
else
step=1
setTimeout("slideit()",2000)
}
slideit()
//-->
</script>
            </div>
            
            <footer>
                <p> © All rights reserved &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Designed and Maintained by Swarup Das, Sabyasachi Moitra, Rana Chanda & Mohona Mukherjee</p>
            </footer>
        </div>
    </body>
</html>

