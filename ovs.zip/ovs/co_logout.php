<!DOCTYPE html>
<html>
<title>On-Line Vote</title>
    <head>
	<link rel="icon" type='image/png' href="vote.png" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo $title; ?></title>
        <link rel="stylesheet" type="text/css" href="Styles/Stylesheet.css" />
		<script type="text/javascript">
		<!-->
var image1=new Image()
image1.src="vote1.jpg"
var image2=new Image()
image2.src="vote2.jpg"
var image3=new Image()
image3.src="Election.jpg"
//-->

</script>
    </head>
    <body>
        <div id="wrapper">
            <div id="banner">             
            </div>
            
            <div id="nav">
                <div id="nav_wrapper">
				<ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#">Login<img src="arr6.png" /></a>
					<ul>
					<li><a href="#">Voter</a></a></li>
					<li><a href="#">Counting Officer</a></li>
					<li><a href="#">Presiding Officer</a></li>
					</ul>	
					</li>	
                    <li><a href="#">Instructions</a></li>
		            <li><a href="#">About</a></li>
                </ul>
				</div>
            </div>
            
            <div id="content_area" style="color:#ffffff; text-align:center;">
                <?php
			 echo "Today is " . date("Y-m-d") ;
			 ?>
			<div id="clockDisplay" class="clockStyle">Time: </div>
<script type="text/javascript" language="javascript">
function renderTime() 
{
		var currentTime = new Date();
		var diem = "AM";
		var h = currentTime.getHours();
		var m = currentTime.getMinutes();
		var s = currentTime.getSeconds();

		if(h==0){
		h=12;
		} else if (h >= 12) {
		h=h-12;
		diem = "PM";
		}
		if(h < 10) {
		h="0" + h;
		}
		if(m < 10) {
		m="0" + m;
		}
		if(s < 10) {
		s="0" + s;
		}
	var myClock=document.getElementById('clockDisplay');
	myClock.textContent = "TIME: " + h + ":" + m + ":" + s + " " + diem;
	setTimeout('renderTime()',1000);
}
renderTime();
</script>
<?php
include_once("dbc.php");
session_start();
session_unset();
?>
<?php
//echo $_SESSION['poid'];
?>
<br /><img src="thumbs-up.png" width="20%" height="20%">
<?php
echo "<h2>You've been successfully logged out!!!<br />";

?>




      
 		</div>
            
            <div id="sidebar">
             <img src="vote1.jpg" name="slide" width="100%" height="100%">
<script type="text/javascript">
<!--
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<3)
step++
else
step=1
setTimeout("slideit()",2000)
}
slideit()
//-->
</script>
            </div>
            
            <footer>
                <p> © All rights reserved &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Designed and Maintained by Swarup Das, Sabyasachi Moitra, Rana Chanda & Mohona Mukherjee</p>
            </footer>
        </div>
    </body>
</html>

