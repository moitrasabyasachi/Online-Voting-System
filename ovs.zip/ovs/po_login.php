<?php
$title = "Login";
$content = '<html>
<body>
<h2>Dear Counting Officer please login here...</h2><br />
<h3>
<form action="po_details.php" method="post">
Enter your ID<br>
<input type="text" name="poname"><br /><br /><br />
<input type="image" src="login3.png">
</h3></form>
</body>
</html>';

include 'Template.php';
?>

