<html>
<?php
echo "I m...";
?>
</html>