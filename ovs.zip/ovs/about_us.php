<!DOCTYPE html>
<html>
<title>On-Line Vote</title>
    <head>
	<link rel="icon" type='image/png' href="vote.png" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo $title; ?></title>
        <link rel="stylesheet" type="text/css" href="Styles/Stylesheet.css" />
		<script type="text/javascript">
		<!-->
var image1=new Image()
image1.src="vote1.jpg"
var image2=new Image()
image2.src="vote2.jpg"
var image3=new Image()
image3.src="Election.jpg"
//-->

</script>
    </head>
    <body>
        <div id="wrapper">
            <div id="banner">             
            </div>
            
            <div id="nav">
                <div id="nav_wrapper">
				<ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#">Login<img src="arr6.png" /></a>
					<ul>
					<li><a href="voter_login.php">Voter</a></a></li>
					
					<li><a href="po_login.php">Counting Officer</a></li>
					<li><a href="co_login.php">Presiding Officer</a></li>
					</ul>	
					</li>	
                    <li><a href="instruction.php">Instructions</a></li>
		            <li><a href="#">About</a></li>
                </ul>
				</div>
            </div>
            
            <div id="content_area" style="color:#ffffff">
             <?php
			 echo "Today is " . date("Y-m-d") ;
			 ?>
			<div id="clockDisplay" class="clockStyle">Time: </div>
<script type="text/javascript" language="javascript">
function renderTime() 
{
		var currentTime = new Date();
		var diem = "AM";
		var h = currentTime.getHours();
		var m = currentTime.getMinutes();
		var s = currentTime.getSeconds();

		if(h==0){
		h=12;
		} else if (h >= 12) {
		h=h-12;
		diem = "PM";
		}
		if(h < 10) {
		h="0" + h;
		}
		if(m < 10) {
		m="0" + m;
		}
		if(s < 10) {
		s="0" + s;
		}
	var myClock=document.getElementById('clockDisplay');
	myClock.textContent = "TIME: " + h + ":" + m + ":" + s + " " + diem;
	setTimeout('renderTime()',1000);
}
renderTime();
</script>
<br /><div style="text-align:center; color:cyan;"><h1>About Us</h1></div>

<div style="color:yellow;"><h3>Project Overview</h3></div>
<p>Online Voting System is a full-service provider of secure, hosted online elections. Our voting system is launched in 2014. They continue to be one of our many happy, repeat customers. We are an agile group and our voting system is constantly evolving with technology and security innovations.
Our Mission: To achieve excellence providing secure and efficient voting solutions and to create value for the organizations we serve.
Our People: Dedicated staff who understand that transparency and perfection are a must in this project team.
Our Strengths: Timely customer service, simplicity of design, high security, and the ability to deliver custom solutions.
<div style="color:yellow;"><h3>Management Team</h3></div>
<div style="color:red;"><b>Swarup Das</b>, Back-end coding, Front-end coding, Group Lead</div>
<p>Swarup manages Online Voting System in 2014 and leads the company. He authored the initial version of the voting system. He now takes an active role in managing staff and supervising operations. He is responsible for the project coding that is done in PHP technology. Swarup is an expert in software security and web application architecture. He holds a Bachelor's degree Physics and a Master's degree in Computer Technology.</p>
<br /><div style="color:red;"><b>Sabyasachi Moitra</b>, Back-end coding, Database Management (MySQL)</div>
<p>Sabyasachi is the key member and his initial idea was behind the making of this website. He has an extensive experience with online voting. He is responsible for coordinating the implementation of solutions and internal project management (Database Management). Sabyasachi graduated and has a Master’s in Computer Technology.</p>
<div style="color:red;"><b>Rana Chanda</b>, Client-Side Scripting</div>
<p>Rana has been a committed member of this website management and creation as his designing and scripting knowledge made this website client communicative and user friendly. His strong understanding of online voting and his ability to translate between technical and common language help us deliver solutions tailored to each industry and customer. Rana attended St.Xavier’s University and was granted a Bachelor of Computer Science and a Master’s degree in Computer Technology.</p>
<div style="color:red;"><b>Mohona Mukherjee</b>, Designing (CSS/HTML)</div>
<p>Mohona has been designing a lot of software project since 2013. Her contribution to this website has been intense and immense. This project boasts of its attractiveness to the user and hence enables the interactivity. She is a graduate of Computer Science and a Master’s degree in Computer Technology. </p><br />

<div style="color:yellow;"><h3>Our Customers</h3></div>
<P>Online Voting System customers appreciate the hard work we've put in to both the software and service.
</P>
<br />
<br />
<br />
<br />
			  <div style="text-align:left">Please Like Us @ &nbsp&nbsp
			  <a href='www.facebook.com'><img class=pop src='Images/facebook-butt.png' width='40px' height='40px' ></a>
			  <img class=pop src='Images/google-button.png' width='40px' height='40px' >
			  <img class=pop src='Images/twitter-button.png' width='40px' height='40px' >
			  <img class=pop src='Images/linkedin-button.png' width='40px' height='40px' ><br /><br /><br />
			  </div>
			  
            </div>
            
            <div id="sidebar">
             <img src="vote1.jpg" name="slide" width="100%" height="100%">
<script type="text/javascript">
<!--
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<3)
step++
else
step=1
setTimeout("slideit()",2000)
}
slideit()
//-->
</script>
			</div>
            <div>
            
            <footer>
                <p> © All rights reserved &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Designed and Maintained by Swarup Das, Sabyasachi Moitra, Rana Chanda & Mohona Mukherjee</p>
            </footer>
			</div>
		</div>
    </body>
</html>
