<?php
$title = "Login";
$content = '<html>
<body>
<h2>Dear Presiding Officer please login to your respective account...</h2><br />
<h3>
<form action="co_details.php" method="post">
Enter your ID<br>
<input type="text" name="coname"><br /><br /><br />
<input type="image" src="login3.png">
</h3></form>
</body>
</html>';

include 'Template.php';
?>

