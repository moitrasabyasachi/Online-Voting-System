<!DOCTYPE html>
<html>
<title>On-Line Vote</title>
    <head>
	<link rel="icon" type='image/png' href="vote.png" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo $title; ?></title>
        <link rel="stylesheet" type="text/css" href="Styles/Stylesheet.css" />
		<script>
  function preventBack(){window.history.forward();}
  setTimeout("preventBack()",0);
  window.onunload=function(){null};
        </script>
		<script type="text/javascript">
		<!-->
var image1=new Image()
image1.src="vote1.jpg"
var image2=new Image()
image2.src="vote2.jpg"
var image3=new Image()
image3.src="Election.jpg"
//-->

</script>
    </head>
    <body>
        <div id="wrapper">
            <div id="banner">             
            </div>
            
            <div id="nav">
                <div id="nav_wrapper">
				<ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Login<img src="arr6.png" /></a>
					<ul>
					<li><a href="#">Voter</a></a></li>
					<li><a href="#">Counting Officer</a></li>
					<li><a href="#">Presiding Officer</a></li>
					</ul>	
					</li>	
                    <li><a href="#">Instructions</a></li>
		            <li><a href="#">About</a></li>
                </ul>
				</div>
            </div>
            
            <div id="content_area" style="color:#ffffff; text-align:center;">
                <h1>VOTING STATUS</h1>
				<?php
include_once("dbc.php");
session_start();
?>

<?php


//echo $_SESSION['id'];
$namec=mysql_query("select zone.zname,worker.zid,(sum(candidate.votes)*10) as percentage from zone,candidate,worker where worker.wid='". $_SESSION['cid']. "' and worker.zid = candidate.zid and zone.zid = candidate.zid")or die(mysql_error());
/*while( $row = mysql_fetch_assoc($namec) ){
			
			
            print "Total votes:  ". $row['total'];
			
          }*/
echo "<br /><br /><table border='1' bgcolor=#CC9933 height='120' width='450'>";
echo "<tr><th>ZONE Name</th><th>Percentage Votes</th></tr>";

while($row = mysql_fetch_array($namec)){   //Creates a loop to loop through results
echo "<form action=counted_details.php method=post>";
//$img=$row['pic'];
//header("Content-type:Image/jpeg");
echo "<td>" . $row['zname'] . "</td><td>" . $row['percentage'] . "%</td>";
echo "</form>";
//$_SESSION['party']=$row['pname'];
}
echo "</table>";

echo "<br /><br /><br /><a href='po_logout.php'><img src='Images/logout-button.png' height='100'></a>";

?>

				
				
				
            </div>
            
            <div id="sidebar">
             <img src="vote1.jpg" name="slide" width="100%" height="100%">
<script type="text/javascript">
<!--
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<3)
step++
else
step=1
setTimeout("slideit()",2000)
}
slideit()
//-->
</script>
            </div>
            
            <footer>
                <p> © All rights reserved &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Designed and Maintained by Swarup Das, Sabyasachi Moitra, Rana Chanda & Mohona Mukherjee</p>
            </footer>
        </div>
    </body>
</html>

