<?php
$title = "Home";
$content = '
<font face="Lucida Console" color="red" style=""><marquee><h2>All voting lines will close on 15th May,2014...</h2></marquee><img src="Images/vote.jpg" class="imgLeft" /></font>

<h3>About On-line Vote</h3>
<p>
    We have been at the forefront of providing e-democratic services since 2000. Our secure online voting platform is now used by hundreds of clients each year and offers the reassurance of proven resistance to hacking and attacks. Clients who have tested and approved our system include financial institutions, accountancy firms, government bodies, law firms, companies, professional institutes, universities, students\' unions and membership organisations of every type and size.
 Every year, over 200 local authorities use it to provide e-registration services to millions of voters, allowing them to register via the internet.
</p>

<img src="Images/Election-Commission1.jpg" class="imgRight"/>
<h3>Election Commission Of India</h3>
<p>
    Our online voting can be used as the sole voting method or combined with postal, telephone or SMS voting to maximise voter convenience and increase turnout.
Electoral Reform Services is able to deliver all elements of an online election, from advertising the election process, through the submission and checking of candidate nominations, to the design and hosting of the site. We provide a simple and easy to use online voting site and most clients prefer our independant brand; however, when required, we can tailor it to suit our clients\' needs or design it as an extension of their own website.

</p>

<img src="Vote-3d.gif" class="imgLeft" />
<h3>Security</h3>
<p>
    For any online election, ballot or referendum, our first priority is security. To that end all our voting websites are built and hosted internally, with no reliance on third parties. Eligible voters log on to one of our voting sites with a security code through a unique ERS-hosted web address.
Our state-of-the-art election software ensures an accurate result every time.
Online and telephone support is offered at all stages for all voters.
</p>
<embed height="50" width="200" src="vote.mp3">';

include 'Template.php';
?>

