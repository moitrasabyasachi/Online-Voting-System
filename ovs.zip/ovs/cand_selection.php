<!DOCTYPE html>
<html>
<title>On-Line Vote</title>
    <head>
	<link rel="icon" type='image/png' href="vote.png" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo $title; ?></title>
        <link rel="stylesheet" type="text/css" href="Styles/Stylesheet.css" />
		
		<script type="text/javascript">
		<!-->
var image1=new Image()
image1.src="vote1.jpg"
var image2=new Image()
image2.src="vote2.jpg"
var image3=new Image()
image3.src="Election.jpg"
//-->

</script>
    </head>
    <body>
        <div id="wrapper">
            <div id="banner">             
            </div>
            
            <div id="nav">
                <div id="nav_wrapper">
				<ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Login<img src="arr6.png" /></a>
					<ul>
					<li><a href="#">Voter</a></a></li>
					<li><a href="#">Counting Officer</a></li>
					<li><a href="#">Presiding Officer</a></li>
					</ul>	
					</li>	
                    <li><a href="#">Instructions</a></li>
		            <li><a href="#">About</a></li>
                </ul>
				</div>
            </div>
            
            <div id="content_area" style="color:#ffffff; text-align:center;">
			<?php
			 echo "Today is " . date("Y-m-d")."<br />" ;
			 ?>
			<div id="clockDisplay" class="clockStyle">Time: </div>
<script type="text/javascript" language="javascript">
function renderTime() 
{
		var currentTime = new Date();
		var diem = "AM";
		var h = currentTime.getHours();
		var m = currentTime.getMinutes();
		var s = currentTime.getSeconds();

		if(h==0){
		h=12;
		} else if (h >= 12) {
		h=h-12;
		diem = "PM";
		}
		if(h < 10) {
		h="0" + h;
		}
		if(m < 10) {
		m="0" + m;
		}
		if(s < 10) {
		s="0" + s;
		}
	var myClock=document.getElementById('clockDisplay');
	myClock.textContent = "TIME: " + h + ":" + m + ":" + s + " " + diem;
	setTimeout('renderTime()',1000);
}
renderTime();
</script>
			<div style="font-size:25px; font-weight:bold; font-family:Courier New; font-style:italic;"><br />Now Please Vote Wisely...Good Luck!</div>
             <br /><img src='voting_booth.gif' width='500' height='300'>  
			 
				<?php 
include_once("dbc.php");
session_start();
?>

<?php


//echo $_SESSION['id'];
$name=mysql_query("select candidate.pic, candidate.cname, party.pname from candidate,elector,party where elector.eid='". $_SESSION['id']. "' and elector.zid = candidate.zid and candidate.pid = party.pid")or die(mysql_error());
echo "<br /><br /><table border='1' bgcolor=#CC9933 height='300'>";
echo "<tr><th>Symbol</th><th>Candidate Name</th><th>Party</th><th>Please Vote any</th></tr>";
$i=1;
while($row = mysql_fetch_array($name)){   //Creates a loop to loop through results
echo "<form action=cand_selection.php method=post>";
echo "<tr><td>";?><img class='popup' src="<?php echo $row['pic'];?>" height='100' width='70'><?php echo "</td><td>" . $row['cname'] . "</td><td>" . $row['pname'] . "</td><td><input type='image' src='blue-button.png' value=Vote name=update".$i."></td></tr>";  //$row['index'] the index here is a field name
$i++;

echo "</form>";
$_SESSION['party']=$row['pname'];
}
echo "</table>";


if(isset($_POST['update1'])){
$updatequery="UPDATE elector SET votes_cast='voted' WHERE eid='" .$_SESSION['id']. "'";
$incquery="UPDATE candidate c inner join elector e on c.zid = e.zid and e.eid='" .$_SESSION['id']. "' and c.pid='P001' SET c.votes = c.votes + 1 ";
mysql_query($updatequery);
mysql_query($incquery);
echo "Thank You...";
session_destroy();
?>
<script type="text/javascript">location.href = 'http://localhost/OnlineVote/voter_end.php';</script>
<?php
}else if(isset($_POST['update2'])){
$updatequery="UPDATE elector SET votes_cast='voted' WHERE eid='" .$_SESSION['id']. "'";
$incquery="UPDATE candidate c inner join elector e on c.zid = e.zid and e.eid='" .$_SESSION['id']. "' and c.pid='P002' SET c.votes = c.votes + 1 ";
mysql_query($updatequery);
mysql_query($incquery);
session_destroy();
?>
<script type="text/javascript">location.href = 'http://localhost/OnlineVote/voter_end.php';</script>
<?php
}
?>

				
				
				
            </div>
            
            <div id="sidebar">
             <img src="vote1.jpg" name="slide" width="100%" height="100%">
<script type="text/javascript">
<!--
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<3)
step++
else
step=1
setTimeout("slideit()",2000)
}
slideit()
//-->
</script>
            </div>
            
            <footer>
                <p> © All rights reserved &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Designed and Maintained by Swarup Das, Sabyasachi Moitra, Rana Chanda & Mohona Mukherjee</p>
            </footer>
        </div>
    </body>
</html>

