
<?php

$title = "Login";
$content = '<html>
<body>
<h2>Dear Voter please login here...</h2><br />
<h3>
<form action="voter_details.php" method="post">
Enter your Voter ID<br>
<input type="text" name="vname"><br /><br /><br />
<input type="image" src="login3.png">
</h3></form>
</body>
</html>';

include 'Template.php';
?>

