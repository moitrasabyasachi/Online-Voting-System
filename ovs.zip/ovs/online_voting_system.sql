-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 22, 2014 at 12:59 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `online_voting_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE IF NOT EXISTS `candidate` (
  `cid` varchar(4) NOT NULL,
  `cname` varchar(20) NOT NULL,
  `pid` varchar(4) NOT NULL,
  `zid` varchar(4) NOT NULL,
  `votes` int(2) NOT NULL,
  `pic` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`cid`, `cname`, `pid`, `zid`, `votes`, `pic`) VALUES
('C001', 'Ravindra Roy', 'P001', 'Z001', 2, 'Images/Sabka _Party.jpg'),
('C002', 'Shah Alam Sheikh', 'P002', 'Z001', 3, 'Images/AIP.jpg'),
('C003', 'Devesh Goswami', 'P001', 'Z002', 2, 'Images/Sabka _Party.jpg'),
('C004', 'Ipsita Mukherjee', 'P002', 'Z002', 1, 'Images/AIP.jpg'),
('C005', 'Sukumar Dhar', 'P001', 'Z003', 0, 'Images/Sabka _Party.jpg'),
('C006', 'Prashant Mohanty', 'P002', 'Z003', 0, 'Images/AIP.jpg'),
('C007', 'Rajesh Sil', 'P001', 'Z004', 0, 'Images/Sabka _Party.jpg'),
('C008', 'Harshit Patel', 'P002', 'Z004', 0, 'Images/AIP.jpg'),
('C009', 'Neetu Pandit', 'P001', 'Z005', 1, 'Images/Sabka _Party.jpg'),
('C010', 'Nagarjuna Das', 'P002', 'Z005', 0, 'Images/AIP.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE IF NOT EXISTS `designation` (
  `did` varchar(4) NOT NULL,
  `dname` varchar(20) NOT NULL,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`did`, `dname`) VALUES
('D001', 'Presiding Officer'),
('D002', 'Counting Officer');

-- --------------------------------------------------------

--
-- Table structure for table `elector`
--

CREATE TABLE IF NOT EXISTS `elector` (
  `eid` varchar(4) NOT NULL,
  `ename` varchar(30) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `age` int(2) NOT NULL,
  `zid` varchar(4) NOT NULL,
  `votes_cast` varchar(10) NOT NULL,
  `voter_pic` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elector`
--

INSERT INTO `elector` (`eid`, `ename`, `sex`, `age`, `zid`, `votes_cast`, `voter_pic`) VALUES
('E001', 'Ashis Naskar', 'Male', 20, 'Z001', 'voted', 'Images/man1.jpg'),
('E002', 'Dibakar Roy', 'Male', 18, 'Z001', 'voted', 'Images/man2.jpg'),
('E003', 'Joseph Das', 'Male', 25, 'Z001', 'voted', 'Images/man3.jpg'),
('E004', 'Rupesh Bhattacharya', 'Male', 36, 'Z001', 'voted', 'Images/man4.jpg'),
('E005', 'Sailen Karmakar', 'Male', 44, 'Z002', 'voted', 'Images/man5.jpg'),
('E006', 'Ram Chandra', 'Male', 53, 'Z002', 'voted', 'Images/man6.jpg'),
('E007', 'Raj Kumar', 'Male', 39, 'Z002', 'voted', 'Images/man7.jpg'),
('E008', 'Neha Rai', 'Female', 24, 'Z002', 'unvoted', NULL),
('E009', 'Hiron Mondal', 'Male', 19, 'Z003', 'unvoted', 'Images/man8.jpg'),
('E010', 'Dinesh Raj', 'Male', 29, 'Z003', 'unvoted', 'Images/man9.jpg'),
('E011', 'Manashi Sharma', 'Female', 34, 'Z003', 'unvoted', NULL),
('E012', 'Dhiraj Sen', 'Male', 55, 'Z003', 'unvoted', NULL),
('E013', 'Raju Das', 'Male', 30, 'Z004', 'unvoted', NULL),
('E014', 'Deblina Dhar', 'Female', 23, 'Z004', 'unvoted', NULL),
('E015', 'Shinjoy kar', 'Male', 37, 'Z004', 'unvoted', NULL),
('E016', 'Tom Walter', 'Male', 49, 'Z004', 'unvoted', NULL),
('E017', 'Rekha Shom', 'Female', 40, 'Z005', 'unvoted', NULL),
('E018', 'Niharika Dey', 'Female', 22, 'Z005', 'unvoted', NULL),
('E019', 'Neeraj Pattanaik', 'Male', 65, 'Z005', 'unvoted', NULL),
('E020', 'Pushar Dey', 'Male', 58, 'Z005', 'voted', NULL),
('E021', 'Prasenjit Chowdhury', 'Male', 25, 'Z001', 'unvoted', NULL),
('E022', 'Indranil Roy', 'Male', 26, 'Z001', 'voted', NULL),
('E023', 'Souvik Banerjee', 'Male', 23, 'Z001', 'unvoted', NULL),
('E024', 'Saikat Sengupta', 'Male', 24, 'Z001', 'unvoted', NULL),
('E025', 'Moutusi Sen', 'Female', 30, 'Z001', 'unvoted', NULL),
('E026', 'Monalisa Sarkar', 'Female', 35, 'Z001', 'unvoted', NULL),
('E027', 'Bishop Sen', 'Male', 40, 'Z002', 'unvoted', NULL),
('E028', 'Deblina Chaudhuri', 'Female', 23, 'Z002', 'unvoted', NULL),
('E029', 'Susovan Das', 'Male', 25, 'Z002', 'unvoted', NULL),
('E030', 'Debopriyo Das', 'Male', 40, 'Z002', 'unvoted', NULL),
('E031', 'Ridip Ghosh', 'Male', 26, 'Z002', 'unvoted', NULL),
('E032', 'Sanchari Guha', 'Female', 34, 'Z002', 'unvoted', NULL),
('E033', 'Tania Singh', 'Female', 30, 'Z003', 'unvoted', NULL),
('E034', 'Ronald Rozario', 'Male', 40, 'Z003', 'unvoted', NULL),
('E035', 'Pinaki Saha', 'Male', 35, 'Z003', 'unvoted', NULL),
('E036', 'Amrita Moitra', 'Female', 29, 'Z003', 'unvoted', NULL),
('E037', 'Arjun Bose', 'Male', 50, 'Z003', 'unvoted', NULL),
('E038', 'Santanu Ghosh', 'Male', 60, 'Z003', 'unvoted', NULL),
('E039', 'Piyali Saha', 'Female', 54, 'Z004', 'unvoted', NULL),
('E040', 'Asoke Nag', 'Male', 70, 'Z004', 'unvoted', NULL),
('E041', 'Arijit Dutta', 'Male', 25, 'Z004', 'unvoted', NULL),
('E042', 'Sampurna Sen', 'Female', 26, 'Z004', 'unvoted', NULL),
('E043', 'Indrasis Guha', 'Male', 30, 'Z004', 'unvoted', NULL),
('E044', 'Anushree Gupta', 'Female', 24, 'Z004', 'unvoted', NULL),
('E045', 'Gautam Pal', 'Male', 26, 'Z005', 'unvoted', NULL),
('E046', 'Anulekha Das', 'Female', 35, 'Z005', 'unvoted', NULL),
('E047', 'Lucky Patel', 'Male', 45, 'Z005', 'unvoted', NULL),
('E048', 'Anupriya Guha', 'Female', 34, 'Z005', 'unvoted', NULL),
('E049', 'Ipshita Sarkar', 'Female', 27, 'Z005', 'unvoted', NULL),
('E050', 'Debarata Das', 'Male', 80, 'Z005', 'unvoted', NULL),
('E051', 'Debjani Mondal', 'Female', 56, 'Z006', 'unvoted', NULL),
('E052', 'Subhasis Saha', 'Male', 67, 'Z006', 'unvoted', NULL),
('E053', 'Ritoban Gupta', 'Male', 45, 'Z006', 'unvoted', NULL),
('E054', 'Argha Basu', 'Male', 27, 'Z006', 'unvoted', NULL),
('E055', 'Rajdeep Bose', 'Male', 26, 'Z006', 'unvoted', NULL),
('E056', 'Indrani Ghosh', 'Female', 35, 'Z006', 'unvoted', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `party`
--

CREATE TABLE IF NOT EXISTS `party` (
  `pid` varchar(4) NOT NULL,
  `pname` varchar(20) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `party`
--

INSERT INTO `party` (`pid`, `pname`) VALUES
('P001', 'Sabka Party'),
('P002', 'Aam Insaan Party');

-- --------------------------------------------------------

--
-- Table structure for table `worker`
--

CREATE TABLE IF NOT EXISTS `worker` (
  `wid` varchar(4) NOT NULL,
  `wname` varchar(20) NOT NULL,
  `did` varchar(4) NOT NULL,
  `zid` varchar(4) NOT NULL,
  PRIMARY KEY (`wid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `worker`
--

INSERT INTO `worker` (`wid`, `wname`, `did`, `zid`) VALUES
('W001', 'Ashis Sen ', 'D001', 'Z001'),
('W002', 'Ramkumar Shaw', 'D002', 'Z001'),
('W003', 'Shibnath Roy', 'D001', 'Z002'),
('W004', 'Somnath Bera', 'D002', 'Z002'),
('W005', 'Harish Sarkar', 'D001', 'Z003'),
('W006', 'Partha Mukherjee', 'D002', 'Z003'),
('W007', 'Aloke Nath', 'D001', 'Z004'),
('W008', 'Anil Sarkar', 'D002', 'Z004'),
('W009', 'Allan Aeo', 'D001', 'Z005'),
('W010', 'Prakash Das', 'D002', 'Z005');

-- --------------------------------------------------------

--
-- Table structure for table `zone`
--

CREATE TABLE IF NOT EXISTS `zone` (
  `zid` varchar(4) NOT NULL,
  `zname` varchar(20) NOT NULL,
  `voters` int(2) NOT NULL,
  `total_votes` int(2) NOT NULL,
  PRIMARY KEY (`zid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `zone`
--

INSERT INTO `zone` (`zid`, `zname`, `voters`, `total_votes`) VALUES
('Z001', 'Dum Dum', 10, 0),
('Z002', 'Barasat', 10, 0),
('Z003', 'Joynagar', 10, 0),
('Z004', 'Diamond Harbour', 10, 0),
('Z005', 'Kolkata Dakshin', 10, 0);
